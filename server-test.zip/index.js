const app = require("./server");
const { initDB } = require("./db");
initDB();

app.listen(3000, () => {
  console.log("Server running on port 3000");
});
